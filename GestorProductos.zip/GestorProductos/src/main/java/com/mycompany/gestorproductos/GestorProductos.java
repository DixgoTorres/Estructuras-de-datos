
package com.mycompany.gestorproductos;

import java.util.Scanner;
public class GestorProductos {
    static String[] nombres = new String[5];
    static double[] precios = new double[5];
    static int contador = 0;
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do{
            System.out.println("\n -- Menu Crud Productos(");
            System.out.println("1. Agregar Productos (CREATE)");
            System.out.println("Seleccione Una Opcion: ");
            opcion = sc.nextInt();
            
            switch(opcion){
                case 1 -> {
                    System.out.println("Nombre del Producto");
                    String nombre = sc.nextLine();
                    
                    System.out.println("Precio del Producto");
                    double precio = sc.nextDouble();
                    agregar(nombre, precio);
                }
                case 0 ->  System.out.println("Saliendo: ");
                default -> System.out.println("Opcion Invalida: ");                
            }            
        }while (opcion != 0 );
         sc.close();
    }
    
    static boolean agregar (String nombre, double precio){
        if (contador >= nombres.length){
            System.out.println("Esta Lleno el Inventario no Hay Espacio Disponible: ");
            return false;
        }
    nombres[contador] = nombre; 
    precios[contador] = precio;
    contador++;
    return true; 
    }
    
    static void listar(){
        if (contador == 0){
            System.out.println("No hay Productos Registrados");
            return ;
        }
        for (int i = 0 ; i < contador ; i ++){
            System.out.println(i + " " +nombres[i] + " " + precios[i]);
        }
    }
}
